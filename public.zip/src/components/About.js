import React from 'react'

function About() {
  return (
    <section className="about-section">
      <div className="container">
        <h2>About Me</h2>
        <p>
          Hi, I’m <strong>Devanand</strong>, a passionate digital content writer with a knack for crafting words that engage, inspire, and convert. With a deep understanding of SEO, storytelling, and audience needs, I help brands communicate their message clearly and effectively.
        </p>
        <p>
          Whether it’s website content, blog articles, social media posts, or marketing copy, I believe in writing content that adds value and drives results. I’ve worked with businesses across various industries, helping them connect with their target audience through impactful writing.
        </p>
        <p>
          When I’m not writing, I enjoy reading, exploring ideas in digital marketing, and staying updated with the latest trends in content strategy.
        </p>
        <p>
          Let's work together to bring your brand’s story to life.
        </p>
      </div>
    </section>
  )
}

export default About
